import yaml
import numpy as np
import torch
import os
from mynetwork import posenet, weights_init
# Please add the downloaded mmfi directory into your python project.
from mynetwork import posenet
from mmfi1 import make_dataset, make_dataloader, MMFi_Dataset, decode_config, MMFi_Database
import torch.nn as nn
from evaluation import compute_pck_pckh
from sklearn.model_selection import train_test_split
from evaluate import compute_similarity_transform, calulate_error
import matplotlib.pyplot as plt
# import get_data_type
dataset_root ='/home/nxhoang/HPE/Data'
with open('config.yaml', 'r') as fd:  # change the .yaml file in your code.
    config = yaml.load(fd, Loader=yaml.FullLoader)

train_dataset, test_dataset = make_dataset(dataset_root, config)
rng_generator = torch.manual_seed(config['init_rand_seed'])
train_loader = make_dataloader(train_dataset, is_training=True, generator=rng_generator, **config['train_loader'])
val_data, test_data = train_test_split(test_dataset, test_size=0.5, random_state=41)
val_loader = make_dataloader(val_data, is_training=False, generator=rng_generator, **config['validation_loader'])
test_loader = make_dataloader(test_data, is_training=False, generator=rng_generator, **config['validation_loader'])


device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
#Initialize model
metafi = posenet()
metafi = metafi.to(device)
metafi.eval()

criterion_L2 = nn.MSELoss().to(device)
optimizer = torch.optim.SGD(metafi.parameters(), lr = 0.001, momentum=0.9)
n_epochs =  50
n_epochs_decay = 60
epoch_count = 1

def lambda_rule(epoch):

    lr_l = 1.0 - max(0, epoch + epoch_count - n_epochs) / float(n_epochs_decay + 1)
    return lr_l
scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: 1.0 - max(0, epoch + epoch_count - n_epochs) / float(n_epochs_decay + 1))
#scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: 1.0 - max(0, epoch + epoch_count - n_epochs) / float(n_epochs_decay + 1))

num_epochs = 50


pck_50_overall_max = 0
train_mean_loss_iter = []
for epoch_index in range(num_epochs):

    loss = 0
    train_loss_iter = []
    metric = []
    metafi.train()
    
    for idx, data in enumerate(train_loader):

        csi_data = data['input_wifi-csi'].to(device)
        #csi_data = csi_data.view(16,2,3,114,10)
        keypoint = data['output'].to(device)#17,3
        print(csi_data.shape)
        print(keypoint.shape)
        exit()
        #x = keypoint[:,:,0]
        #y = keypoint[:,:,1]
        #c = keypoint[:,:,2]
        #keymatrix = np.zeros([3,17,17])
        #for row in range(17):
        #    for column in range(17):
        #        if row == column:
        #            keymatrix[:,row,column] = [x[row], y[row], c[row]]
        #        else:
        #            keymatrix[:,row,column] = [x[row]-x[column], y[row]-y[column], c[row]*c[column]]

        #keymatrix = torch.tensor(keymatrix)
        
        xy_keypoint = keypoint[:,:, 0:2]
        confidence = keypoint[:,:, 2:3]
            
       

        pred_xy_keypoint, time = metafi(csi_data,32) #b,2,17,17
        pred_xy_keypoint = pred_xy_keypoint.squeeze()
        #pred_xy_keypoint = torch.transpose(pred_xy_keypoint, 1, 2)
        
        #loss = tf.reduce_mean(tf.pow(pred_xy_keypoint - xy_keypoint, 2))
        #loss = criterion_L2(pred_xy_keypoint, xy_keypoint)/32
        loss = criterion_L2(torch.mul(confidence, pred_xy_keypoint), torch.mul(confidence, xy_keypoint))/32
        train_loss_iter.append(loss.cpu().detach().numpy())

        optimizer.zero_grad()

        loss.backward()
        optimizer.step()

        lr = np.array(scheduler.get_last_lr())
        message = '(epoch: %d, iters: %d, lr: %.5f, loss: %.3f) ' % (epoch_index, idx * 32, lr, loss)
        print(message)
    scheduler.step()
    train_mean_loss = np.mean(train_loss_iter)
    train_mean_loss_iter.append(train_mean_loss)
    print('end of the epoch: %d, with loss: %.3f' % (epoch_index, train_mean_loss,))


    metafi.eval()
    valid_loss_iter = []
    #metric = []
    pck_50_iter = []
    pck_20_iter = []
    with torch.no_grad():
        for idx, data in enumerate(val_loader):
            csi_data = data['input_wifi-csi'].to(device)
            keypoint = data['output'].to(device)#17,3
            # xy_keypoint = data['keypoint'].unsqueeze(0)
            #csi_data = csi_data.cuda().unsqueeze(0)
            #csi_data = csi_data.type(torch.cuda.FloatTensor)
            #label = label.cuda().unsqueeze(0)
            #xy = label[:, 0:2, :, :]
            #confidence = label[:, 2:3, :, :]
            xy_keypoint = keypoint[:,:, 0:2]
            confidence = keypoint[:,:, 2:3]

            pred_xy_keypoint,time = metafi(csi_data,1)  # 4,2,17,17
            pred_xy_keypoint = pred_xy_keypoint.squeeze()
            pred_xy_keypoint = pred_xy_keypoint.reshape(1,17,2)
            
            #loss = tf.reduce_mean(tf.pow(pred_xy_keypoint - xy_keypoint, 2))
            loss = criterion_L2(torch.mul(confidence, pred_xy_keypoint), torch.mul(confidence, xy_keypoint))
            #loss = criterion_L2(pred_xy_keypoint, xy_keypoint)
            
            valid_loss_iter.append(loss.cpu().detach().numpy())
            pred_xy_keypoint = pred_xy_keypoint.cpu()
            xy_keypoint = xy_keypoint.cpu()
            #pred_xy_keypoint = torch.transpose(pred_xy_keypoint, 0, 1).unsqueeze(dim=0)
            #xy_keypoint = torch.transpose(xy_keypoint, 0, 1).unsqueeze(dim=0)
            pred_xy_keypoint_pck = torch.transpose(pred_xy_keypoint, 1, 2)
            xy_keypoint_pck = torch.transpose(xy_keypoint, 1, 2)
            #keypoint = torch.transpose(keypoint, 1, 2)
            #pred_xy_keypoint_pck = pred_xy_keypoint.cpu()
            #xy_keypoint_pck = xy_keypoint.cpu()
            pck = compute_pck_pckh(pred_xy_keypoint_pck, xy_keypoint_pck, 0.5)
            #mpjpe,pa_mpjpe = calulate_error(pred_xy_keypoint, xy_keypoint)
             
            metric.append(calulate_error(pred_xy_keypoint, xy_keypoint))
            pck_50_iter.append(compute_pck_pckh(pred_xy_keypoint_pck, xy_keypoint_pck, 0.5))
            pck_20_iter.append(compute_pck_pckh(pred_xy_keypoint_pck, xy_keypoint_pck, 0.2))
            
            #message1 = '( loss: %.3f) ' % (loss)
            #print(message1)
            #pck_50_iter.append(compute_pck_pckh(pred_xy_keypoint, xy_keypoint, 0.5))
            #pck_20_iter.append(compute_pck_pckh(pred_xy_keypoint, xy_keypoint, 0.2))

        valid_mean_loss = np.mean(valid_loss_iter)
        mpjpe_mean = np.mean(metric[0])*1000
        pa_mpjpe_mean = np.mean(metric[1])*1000

        pck_50 = np.mean(pck_50_iter,0)
        pck_20 = np.mean(pck_20_iter,0)
        pck_50_overall = pck_50[17]
        pck_20_overall = pck_20[17]
        print('validation result with loss: %.3f, pck_50: %.3f, pck_20: %.3f, mpjpe: %.3f, pa_mpjpe: %.3f' % (valid_mean_loss, pck_50_overall,pck_20_overall, mpjpe_mean, pa_mpjpe_mean))
        
        if pck_50_overall > pck_50_overall_max:
           print('saving the model at the end of epoch %d with pck_50: %.3f' % (epoch_index, pck_50_overall))
           torch.save(metafi, 'get_train.py')
           pck_50_overall_max = pck_50_overall

        #

        #     print('the train loss for the first %.1f epoch is' % (epoch_index))
        #     print(train_mean_loss_iter)

plt.plot(range(len(train_mean_loss_iter)), train_mean_loss_iter)
plt.title('Tran Loss Function')
plt.xlabel('Iter')
plt.ylabel('MSE Loss')
plt.grid(True)
plt.show()

        # plt.plot(range(len(valid_mean_loss)), valid_mean_loss)
        # plt.title('Test Loss Function')
        # plt.xlabel('Iter')
        # plt.ylabel('MSE Loss')
        # plt.grid(True)
        # plt.show()


        







